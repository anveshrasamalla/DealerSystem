﻿Public Class CreateOrder


    Private DBConn As CarSalesContext = New CarSalesContext
    Dim OrderID As Integer
    Dim CustomerID As Integer
    Dim EmployeesID As Integer
    Dim FirstName As String
    Dim LastName As String
    Dim OrderDate As Date
    Dim RequiredDate As Date
    Dim ShippingDate As Date
    Dim CarID As Integer
    Dim rowcount As Integer
    Dim Discount As Decimal



    Private Sub SaveButton_Click(sender As Object, e As EventArgs) Handles CreateOrderButton.Click

        DBConn.AddParam("@CustomerID", CustomerID_TB.Text)
        DBConn.AddParam("@EmolyeesID", EmployeeID_TB.Text)
        DBConn.AddParam("@OrderDate", OrderDate_TB.Text)
        DBConn.AddParam("@RequiredDate", RequiredDate_TB.Text)
        DBConn.AddParam("@ShippingDate", ShippingDate_TB.Text)
        DBConn.AddParam("@Discount", Discount_TB.Text)
        DBConn.AddParam("@CarID", CarID_TB.Text)
        DBConn.AddParam("@price", price_TB.Text)




        DBConn.ExecuteQuery("insert into Orders(CustomerID,EmployeesID,OrderDate,RequiredDate,ShippingDate,carID,Discount) VALUES(?,?,?,?,?,?,?)")
        If DBConn.Exception <> String.Empty Then
            MessageBox.Show(DBConn.Exception)
            Exit Sub
        End If

        MessageBox.Show("New Order data entered successfully", "New Order data")

    End Sub



    Private Sub CreateOrder_Load(sender As Object, e As EventArgs) Handles MyBase.Load



    End Sub

    Private Sub Cancel_Button_Click(sender As Object, e As EventArgs) Handles Cancel_Button.Click
        Me.Close()

    End Sub

    Private Sub CarsDataGridView_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles CarsDataGridView.CellContentClick
        Dim i As Integer

        i = CarsDataGridView.CurrentRow.Index

        CarID_TB.Text = CarsDataGridView.Item(0, i).Value
        CarName_TB.Text = CarsDataGridView.Item(2, i).Value

        Brand_TB.Text = CarsDataGridView.Item(1, i).Value

        price_TB.Text = CarsDataGridView.Item(4, i).Value


    End Sub

    Private Sub ShowAllCarsButton_Click(sender As Object, e As EventArgs) Handles ShowAllCarsButton.Click
        DBConn.ExecuteQuery("select CarID,brand,Carname,model,price,makeyear from cars 
where carid not in (select carID from orders)")

        If DBConn.Exception <> String.Empty Then
            MessageBox.Show(DBConn.Exception)
            Exit Sub
        End If
        CarsDataGridView.ForeColor = Color.Black
        CarsDataGridView.DataSource = DBConn.DBDataTable
        columnsize()
        rowcount = CInt(DBConn.RecordCount)
        'Me.CarID_TB.Text = (DBConn.RecordCount + 1).ToString

    End Sub

    Private Sub columnsize()
        Dim column0 As DataGridViewColumn = CarsDataGridView.Columns(0)
        column0.Width = 35
        column0.HeaderCell.Value = "CarID"

        Dim column1 As DataGridViewColumn = CarsDataGridView.Columns(1)
        column1.Width = 65

        column1.HeaderCell.Value = "Brand"
        Dim column2 As DataGridViewColumn = CarsDataGridView.Columns(2)
        column2.Width = 65
        column2.HeaderCell.Value = "car name"

        Dim column3 As DataGridViewColumn = CarsDataGridView.Columns(3)
        column3.Width = 65
        column3.HeaderCell.Value = "Model"

        Dim column4 As DataGridViewColumn = CarsDataGridView.Columns(4)
        column4.Width = 35
        column4.HeaderCell.Value = "price"

        Dim column5 As DataGridViewColumn = CarsDataGridView.Columns(5)
        column5.Width = 35
        column5.HeaderCell.Value = "make year"

    End Sub

    Private Sub CustomerID_TB_TextChanged(sender As Object, e As EventArgs) Handles CustomerID_TB.TextChanged
        'CustomerID_TB = DBConn.ExecuteQuery("Select customerid from customers where firstname Like '%Firstname_TB %' and lastname like '% Lastname_TB%'")
    End Sub
End Class