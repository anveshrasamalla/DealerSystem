﻿Public Class Orders
    Public Property OrderID As String
    Public Property CustomerID As String
    Public Property EmployeesID As String
    Public Property OrderDate As Date
    Public Property RequiredDate As Date
    Public Property ShippingDate As Date
    Public Property carID As Integer
    Public Property price As Integer
    Public Property Discount As Integer



End Class
