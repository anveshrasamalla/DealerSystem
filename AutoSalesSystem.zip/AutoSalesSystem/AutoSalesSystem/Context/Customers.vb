﻿Public Class Customers
    Public Property CustomerID As String
    Public Property FirstName As String
    Public Property LastName As String

End Class
