﻿Public Class EditOrder
    Private DBConn As CarSalesContext = New CarSalesContext
    Dim rowcount As Integer


    Private Sub EditOrder_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub SearchOrdersButton_Click(sender As Object, e As EventArgs) Handles SearchOrdersButton.Click
        DBConn.ExecuteQuery("select OrderID,CustomerID,EmployeesID,OrderDate,RequiredDate,ShippingDate,carID,price,Discount,brand,carname 
from Orders where orderid=" & OrderID_TB.Text & "")

        OrderID_TB.Text = DBConn.DBDataTable(0)!OrderID


        If DBConn.Exception <> String.Empty Then
            MessageBox.Show(DBConn.Exception)
            Exit Sub
        End If
        OrdersDataGridView.ForeColor = Color.Black
        OrdersDataGridView.DataSource = DBConn.DBDataTable
        columnsize()
        rowcount = CInt(DBConn.RecordCount)
        'Me.CarID_TB.Text = (DBConn.RecordCount + 1).ToString
    End Sub



    Private Sub columnsize()
        Dim column0 As DataGridViewColumn = OrdersDataGridView.Columns(0)
        column0.Width = 35
        column0.HeaderCell.Value = "OrderID"

        Dim column1 As DataGridViewColumn = OrdersDataGridView.Columns(1)
        column1.Width = 65
        column1.HeaderCell.Value = "CustomerID"

        Dim column2 As DataGridViewColumn = OrdersDataGridView.Columns(2)
        column2.Width = 65
        column2.HeaderCell.Value = "EmployeesID"

        Dim column3 As DataGridViewColumn = OrdersDataGridView.Columns(3)
        column3.Width = 65
        column3.HeaderCell.Value = "OrderDate"

        Dim column4 As DataGridViewColumn = OrdersDataGridView.Columns(4)
        column4.Width = 35
        column4.HeaderCell.Value = "RequiredDate"

        Dim column5 As DataGridViewColumn = OrdersDataGridView.Columns(5)
        column5.Width = 35
        column5.HeaderCell.Value = "ShippingDate"

        Dim column6 As DataGridViewColumn = OrdersDataGridView.Columns(6)
        column6.Width = 35
        column6.HeaderCell.Value = "carID"


        Dim column7 As DataGridViewColumn = OrdersDataGridView.Columns(7)
        column7.Width = 35
        column7.HeaderCell.Value = "price"

        Dim column8 As DataGridViewColumn = OrdersDataGridView.Columns(8)
        column8.Width = 35
        column8.HeaderCell.Value = "Discount"

        Dim column9 As DataGridViewColumn = OrdersDataGridView.Columns(9)
        column9.Width = 35
        column9.HeaderCell.Value = "brand"

        Dim column10 As DataGridViewColumn = OrdersDataGridView.Columns(10)
        column10.Width = 35
        column10.HeaderCell.Value = "carname"



    End Sub

    Private Sub OrdersDataGridView_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles OrdersDataGridView.CellContentClick
        Dim j As Integer

        j = OrdersDataGridView.CurrentRow.Index

        OrderDate_TB.Text = OrdersDataGridView.Item(3, j).Value
        RequiredDate_TB.Text = OrdersDataGridView.Item(4, j).Value
        ShippingDate_TB.Text = OrdersDataGridView.Item(5, j).Value
        CarName_TB.Text = OrdersDataGridView.Item(10, j).Value
        CarID_TB.Text = OrdersDataGridView.Item(6, j).Value
        Brand_TB.Text = OrdersDataGridView.Item(9, j).Value
        price_TB.Text = OrdersDataGridView.Item(7, j).Value
        Discount_TB.Text = OrdersDataGridView.Item(8, j).Value
    End Sub

    Private Sub UpdateOdrerButton_Click(sender As Object, e As EventArgs) Handles UpdateOdrerButton.Click

        DBConn.AddParam("@OrderDate", OrderDate_TB.Text)
        DBConn.AddParam("@RequiredDate", RequiredDate_TB.Text)
        DBConn.AddParam("@ShippingDate", ShippingDate_TB.Text)
        DBConn.AddParam("@Discount", Discount_TB.Text)


        DBConn.ExecuteQuery("UPDATE orders SET OrderDate=?,RequiredDate=?,ShippingDate=?,Discount=? where Orderid=" & OrderID_TB.Text & "")
        If DBConn.Exception <> String.Empty Then
            MessageBox.Show(DBConn.Exception)
            Exit Sub
        End If

        MessageBox.Show("Order Updated Succesfully", "New Order data")
    End Sub

    Private Sub DeleteOrderButton_Click(sender As Object, e As EventArgs) Handles DeleteOrderButton.Click
        DBConn.ExecuteQuery("Delete from  orders  where Orderid=" & OrderID_TB.Text & "")
        If DBConn.Exception <> String.Empty Then
            MessageBox.Show(DBConn.Exception)
            Exit Sub
        End If

        MessageBox.Show("Order Deleted Succesfully", "New Order data")
    End Sub

    Private Sub Cancel_Button_Click(sender As Object, e As EventArgs) Handles Cancel_Button.Click
        Me.Close()
    End Sub
End Class