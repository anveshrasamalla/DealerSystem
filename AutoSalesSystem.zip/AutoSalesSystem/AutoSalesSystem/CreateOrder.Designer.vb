﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CreateOrder
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.FirstName_TB = New System.Windows.Forms.TextBox()
        Me.LastName_TB = New System.Windows.Forms.TextBox()
        Me.CustomerID_TB = New System.Windows.Forms.TextBox()
        Me.EmployeeID_TB = New System.Windows.Forms.TextBox()
        Me.ShowAllCarsButton = New System.Windows.Forms.Button()
        Me.CreateOrderButton = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Discount_TB = New System.Windows.Forms.TextBox()
        Me.CarID_TB = New System.Windows.Forms.TextBox()
        Me.Label = New System.Windows.Forms.Label()
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.CarsDataGridView = New System.Windows.Forms.DataGridView()
        Me.OrderDate_TB = New System.Windows.Forms.DateTimePicker()
        Me.ShippingDate_TB = New System.Windows.Forms.DateTimePicker()
        Me.RequiredDate_TB = New System.Windows.Forms.DateTimePicker()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.price_TB = New System.Windows.Forms.TextBox()
        Me.Brand = New System.Windows.Forms.Label()
        Me.CarName_TB = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Brand_TB = New System.Windows.Forms.TextBox()
        CType(Me.CarsDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 68)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(104, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Customer First Name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(251, 68)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(105, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Customer Last Name"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(498, 68)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Customer ID"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 140)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(64, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "EmployeeID"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(251, 140)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(59, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Order Date"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(12, 206)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(76, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Required Date"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(370, 207)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(74, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Shipping Date"
        '
        'FirstName_TB
        '
        Me.FirstName_TB.Location = New System.Drawing.Point(122, 65)
        Me.FirstName_TB.Name = "FirstName_TB"
        Me.FirstName_TB.Size = New System.Drawing.Size(100, 20)
        Me.FirstName_TB.TabIndex = 11
        '
        'LastName_TB
        '
        Me.LastName_TB.Location = New System.Drawing.Point(362, 65)
        Me.LastName_TB.Name = "LastName_TB"
        Me.LastName_TB.Size = New System.Drawing.Size(100, 20)
        Me.LastName_TB.TabIndex = 15
        '
        'CustomerID_TB
        '
        Me.CustomerID_TB.Location = New System.Drawing.Point(591, 65)
        Me.CustomerID_TB.Name = "CustomerID_TB"
        Me.CustomerID_TB.Size = New System.Drawing.Size(100, 20)
        Me.CustomerID_TB.TabIndex = 16
        '
        'EmployeeID_TB
        '
        Me.EmployeeID_TB.Location = New System.Drawing.Point(122, 133)
        Me.EmployeeID_TB.Name = "EmployeeID_TB"
        Me.EmployeeID_TB.Size = New System.Drawing.Size(100, 20)
        Me.EmployeeID_TB.TabIndex = 17
        '
        'ShowAllCarsButton
        '
        Me.ShowAllCarsButton.Location = New System.Drawing.Point(294, 260)
        Me.ShowAllCarsButton.Name = "ShowAllCarsButton"
        Me.ShowAllCarsButton.Size = New System.Drawing.Size(168, 23)
        Me.ShowAllCarsButton.TabIndex = 21
        Me.ShowAllCarsButton.Text = "Show All  Cars"
        Me.ShowAllCarsButton.UseVisualStyleBackColor = True
        '
        'CreateOrderButton
        '
        Me.CreateOrderButton.Location = New System.Drawing.Point(122, 629)
        Me.CreateOrderButton.Name = "CreateOrderButton"
        Me.CreateOrderButton.Size = New System.Drawing.Size(75, 23)
        Me.CreateOrderButton.TabIndex = 22
        Me.CreateOrderButton.Text = "Create Order"
        Me.CreateOrderButton.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(456, 520)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(49, 13)
        Me.Label14.TabIndex = 30
        Me.Label14.Text = "Discount"
        '
        'Discount_TB
        '
        Me.Discount_TB.Location = New System.Drawing.Point(511, 517)
        Me.Discount_TB.Name = "Discount_TB"
        Me.Discount_TB.Size = New System.Drawing.Size(100, 20)
        Me.Discount_TB.TabIndex = 31
        '
        'CarID_TB
        '
        Me.CarID_TB.BackColor = System.Drawing.SystemColors.ControlLight
        Me.CarID_TB.Enabled = False
        Me.CarID_TB.Location = New System.Drawing.Point(71, 510)
        Me.CarID_TB.Name = "CarID_TB"
        Me.CarID_TB.Size = New System.Drawing.Size(100, 20)
        Me.CarID_TB.TabIndex = 32
        '
        'Label
        '
        Me.Label.AutoSize = True
        Me.Label.Location = New System.Drawing.Point(28, 513)
        Me.Label.Name = "Label"
        Me.Label.Size = New System.Drawing.Size(37, 13)
        Me.Label.TabIndex = 33
        Me.Label.Text = "Car ID"
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Location = New System.Drawing.Point(536, 629)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.Size = New System.Drawing.Size(75, 23)
        Me.Cancel_Button.TabIndex = 37
        Me.Cancel_Button.Text = "Cancel"
        Me.Cancel_Button.UseVisualStyleBackColor = True
        '
        'CarsDataGridView
        '
        Me.CarsDataGridView.AllowUserToOrderColumns = True
        Me.CarsDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.CarsDataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.CarsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.CarsDataGridView.Location = New System.Drawing.Point(122, 289)
        Me.CarsDataGridView.Name = "CarsDataGridView"
        Me.CarsDataGridView.Size = New System.Drawing.Size(450, 150)
        Me.CarsDataGridView.TabIndex = 38
        '
        'OrderDate_TB
        '
        Me.OrderDate_TB.CustomFormat = "yyyy-MM-dd"
        Me.OrderDate_TB.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.OrderDate_TB.Location = New System.Drawing.Point(362, 134)
        Me.OrderDate_TB.Name = "OrderDate_TB"
        Me.OrderDate_TB.Size = New System.Drawing.Size(200, 20)
        Me.OrderDate_TB.TabIndex = 39
        '
        'ShippingDate_TB
        '
        Me.ShippingDate_TB.CustomFormat = "yyyy-MM-dd"
        Me.ShippingDate_TB.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.ShippingDate_TB.Location = New System.Drawing.Point(501, 207)
        Me.ShippingDate_TB.Name = "ShippingDate_TB"
        Me.ShippingDate_TB.Size = New System.Drawing.Size(200, 20)
        Me.ShippingDate_TB.TabIndex = 40
        '
        'RequiredDate_TB
        '
        Me.RequiredDate_TB.CustomFormat = "yyyy-MM-dd"
        Me.RequiredDate_TB.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.RequiredDate_TB.Location = New System.Drawing.Point(122, 207)
        Me.RequiredDate_TB.Name = "RequiredDate_TB"
        Me.RequiredDate_TB.Size = New System.Drawing.Size(200, 20)
        Me.RequiredDate_TB.TabIndex = 41
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(248, 516)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(31, 13)
        Me.Label9.TabIndex = 44
        Me.Label9.Text = "Price"
        '
        'price_TB
        '
        Me.price_TB.Location = New System.Drawing.Point(285, 513)
        Me.price_TB.Name = "price_TB"
        Me.price_TB.Size = New System.Drawing.Size(100, 20)
        Me.price_TB.TabIndex = 45
        '
        'Brand
        '
        Me.Brand.AutoSize = True
        Me.Brand.Location = New System.Drawing.Point(28, 560)
        Me.Brand.Name = "Brand"
        Me.Brand.Size = New System.Drawing.Size(35, 13)
        Me.Brand.TabIndex = 46
        Me.Brand.Text = "Brand"
        '
        'CarName_TB
        '
        Me.CarName_TB.Location = New System.Drawing.Point(285, 560)
        Me.CarName_TB.Name = "CarName_TB"
        Me.CarName_TB.Size = New System.Drawing.Size(100, 20)
        Me.CarName_TB.TabIndex = 47
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(225, 560)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(54, 13)
        Me.Label8.TabIndex = 48
        Me.Label8.Text = "Car Name"
        '
        'Brand_TB
        '
        Me.Brand_TB.Location = New System.Drawing.Point(71, 557)
        Me.Brand_TB.Name = "Brand_TB"
        Me.Brand_TB.Size = New System.Drawing.Size(100, 20)
        Me.Brand_TB.TabIndex = 49
        '
        'CreateOrder
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(746, 664)
        Me.Controls.Add(Me.Brand_TB)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.CarName_TB)
        Me.Controls.Add(Me.Brand)
        Me.Controls.Add(Me.price_TB)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.RequiredDate_TB)
        Me.Controls.Add(Me.ShippingDate_TB)
        Me.Controls.Add(Me.OrderDate_TB)
        Me.Controls.Add(Me.CarsDataGridView)
        Me.Controls.Add(Me.Cancel_Button)
        Me.Controls.Add(Me.Label)
        Me.Controls.Add(Me.CarID_TB)
        Me.Controls.Add(Me.Discount_TB)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.CreateOrderButton)
        Me.Controls.Add(Me.ShowAllCarsButton)
        Me.Controls.Add(Me.EmployeeID_TB)
        Me.Controls.Add(Me.CustomerID_TB)
        Me.Controls.Add(Me.LastName_TB)
        Me.Controls.Add(Me.FirstName_TB)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "CreateOrder"
        Me.Text = "Create  Order"
        CType(Me.CarsDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents FirstName_TB As TextBox
    Friend WithEvents LastName_TB As TextBox
    Friend WithEvents CustomerID_TB As TextBox
    Friend WithEvents EmployeeID_TB As TextBox
    Friend WithEvents ShowAllCarsButton As Button
    Friend WithEvents CreateOrderButton As Button
    Friend WithEvents Label14 As Label
    Friend WithEvents Discount_TB As TextBox
    Friend WithEvents CarID_TB As TextBox
    Friend WithEvents Label As Label
    Friend WithEvents Cancel_Button As Button
    Friend WithEvents CarsDataGridView As DataGridView
    Friend WithEvents OrderDate_TB As DateTimePicker
    Friend WithEvents ShippingDate_TB As DateTimePicker
    Friend WithEvents RequiredDate_TB As DateTimePicker
    Friend WithEvents Label9 As Label
    Friend WithEvents price_TB As TextBox
    Friend WithEvents Brand As Label
    Friend WithEvents CarName_TB As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Brand_TB As TextBox
End Class
