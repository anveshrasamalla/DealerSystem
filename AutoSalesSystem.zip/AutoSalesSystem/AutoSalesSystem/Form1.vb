﻿Public Class Home
    Private Sub NewOrderToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NewOrderToolStripMenuItem.Click
        CreateOrder.Show()
    End Sub

    Private Sub Home_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub EditOrderToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EditOrderToolStripMenuItem.Click
        EditOrder.Show()

    End Sub

    Private Sub InsuranceDetailsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InsuranceDetailsToolStripMenuItem.Click
        InsuranceDetails.Show()
    End Sub
End Class
