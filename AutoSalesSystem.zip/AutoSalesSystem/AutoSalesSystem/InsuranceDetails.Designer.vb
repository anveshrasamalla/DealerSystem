﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class InsuranceDetails
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.OrdersDataGridView = New System.Windows.Forms.DataGridView()
        Me.OrderSearchButton = New System.Windows.Forms.Button()
        Me.OrderID_TB = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.CarID_TB = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.InsDescription_TB = New System.Windows.Forms.TextBox()
        Me.InsuranceCompComboBox = New System.Windows.Forms.ComboBox()
        Me.Price_TB = New System.Windows.Forms.TextBox()
        Me.CoverageComboBox = New System.Windows.Forms.ComboBox()
        Me.SaveButton = New System.Windows.Forms.Button()
        Me.CancelButton = New System.Windows.Forms.Button()
        CType(Me.OrdersDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(56, 43)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(44, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "OrderID"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(56, 92)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(0, 13)
        Me.Label2.TabIndex = 1
        '
        'OrdersDataGridView
        '
        Me.OrdersDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.OrdersDataGridView.Location = New System.Drawing.Point(59, 76)
        Me.OrdersDataGridView.Name = "OrdersDataGridView"
        Me.OrdersDataGridView.Size = New System.Drawing.Size(429, 150)
        Me.OrdersDataGridView.TabIndex = 3
        '
        'OrderSearchButton
        '
        Me.OrderSearchButton.Location = New System.Drawing.Point(348, 38)
        Me.OrderSearchButton.Name = "OrderSearchButton"
        Me.OrderSearchButton.Size = New System.Drawing.Size(140, 23)
        Me.OrderSearchButton.TabIndex = 4
        Me.OrderSearchButton.Text = "Search Orders"
        Me.OrderSearchButton.UseVisualStyleBackColor = True
        '
        'OrderID_TB
        '
        Me.OrderID_TB.Location = New System.Drawing.Point(139, 40)
        Me.OrderID_TB.Name = "OrderID_TB"
        Me.OrderID_TB.Size = New System.Drawing.Size(100, 20)
        Me.OrderID_TB.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(28, 273)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(37, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Car ID"
        '
        'CarID_TB
        '
        Me.CarID_TB.Location = New System.Drawing.Point(139, 270)
        Me.CarID_TB.Name = "CarID_TB"
        Me.CarID_TB.Size = New System.Drawing.Size(121, 20)
        Me.CarID_TB.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(316, 273)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(101, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Insurance Company"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(28, 324)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(110, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Insurance Description"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(28, 375)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(53, 13)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Coverage"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(316, 328)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(31, 13)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "Price"
        '
        'InsDescription_TB
        '
        Me.InsDescription_TB.Location = New System.Drawing.Point(139, 321)
        Me.InsDescription_TB.Name = "InsDescription_TB"
        Me.InsDescription_TB.Size = New System.Drawing.Size(121, 20)
        Me.InsDescription_TB.TabIndex = 13
        '
        'InsuranceCompComboBox
        '
        Me.InsuranceCompComboBox.FormattingEnabled = True
        Me.InsuranceCompComboBox.Items.AddRange(New Object() {"American Family Insurance", "State Farm", "Progressive", "Auto Owners", "Wolverine"})
        Me.InsuranceCompComboBox.Location = New System.Drawing.Point(448, 270)
        Me.InsuranceCompComboBox.Name = "InsuranceCompComboBox"
        Me.InsuranceCompComboBox.Size = New System.Drawing.Size(121, 21)
        Me.InsuranceCompComboBox.TabIndex = 15
        '
        'Price_TB
        '
        Me.Price_TB.Location = New System.Drawing.Point(448, 321)
        Me.Price_TB.Name = "Price_TB"
        Me.Price_TB.Size = New System.Drawing.Size(121, 20)
        Me.Price_TB.TabIndex = 16
        '
        'CoverageComboBox
        '
        Me.CoverageComboBox.FormattingEnabled = True
        Me.CoverageComboBox.Items.AddRange(New Object() {"Full", "Partial"})
        Me.CoverageComboBox.Location = New System.Drawing.Point(139, 372)
        Me.CoverageComboBox.Name = "CoverageComboBox"
        Me.CoverageComboBox.Size = New System.Drawing.Size(121, 21)
        Me.CoverageComboBox.TabIndex = 17
        '
        'SaveButton
        '
        Me.SaveButton.Location = New System.Drawing.Point(93, 438)
        Me.SaveButton.Name = "SaveButton"
        Me.SaveButton.Size = New System.Drawing.Size(75, 23)
        Me.SaveButton.TabIndex = 18
        Me.SaveButton.Text = "Save"
        Me.SaveButton.UseVisualStyleBackColor = True
        '
        'CancelButton
        '
        Me.CancelButton.Location = New System.Drawing.Point(348, 438)
        Me.CancelButton.Name = "CancelButton"
        Me.CancelButton.Size = New System.Drawing.Size(75, 23)
        Me.CancelButton.TabIndex = 19
        Me.CancelButton.Text = "Cancel"
        Me.CancelButton.UseVisualStyleBackColor = True
        '
        'InsuranceDetails
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(637, 477)
        Me.Controls.Add(Me.CancelButton)
        Me.Controls.Add(Me.SaveButton)
        Me.Controls.Add(Me.CoverageComboBox)
        Me.Controls.Add(Me.Price_TB)
        Me.Controls.Add(Me.InsuranceCompComboBox)
        Me.Controls.Add(Me.InsDescription_TB)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.CarID_TB)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.OrderID_TB)
        Me.Controls.Add(Me.OrderSearchButton)
        Me.Controls.Add(Me.OrdersDataGridView)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "InsuranceDetails"
        Me.Text = "InsuranceDetails"
        CType(Me.OrdersDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents OrdersDataGridView As DataGridView
    Friend WithEvents OrderSearchButton As Button
    Friend WithEvents OrderID_TB As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents CarID_TB As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents InsDescription_TB As TextBox
    Friend WithEvents InsuranceCompComboBox As ComboBox
    Friend WithEvents Price_TB As TextBox
    Friend WithEvents CoverageComboBox As ComboBox
    Friend WithEvents SaveButton As Button
    Friend WithEvents CancelButton As Button
End Class
