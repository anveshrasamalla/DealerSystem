﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class EditOrder
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Brand_TB = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.CarName_TB = New System.Windows.Forms.TextBox()
        Me.Brand = New System.Windows.Forms.Label()
        Me.price_TB = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.RequiredDate_TB = New System.Windows.Forms.DateTimePicker()
        Me.ShippingDate_TB = New System.Windows.Forms.DateTimePicker()
        Me.OrdersDataGridView = New System.Windows.Forms.DataGridView()
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.Label = New System.Windows.Forms.Label()
        Me.CarID_TB = New System.Windows.Forms.TextBox()
        Me.Discount_TB = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.UpdateOdrerButton = New System.Windows.Forms.Button()
        Me.OrderID_TB = New System.Windows.Forms.TextBox()
        Me.CustomerID_TB = New System.Windows.Forms.TextBox()
        Me.LastName_TB = New System.Windows.Forms.TextBox()
        Me.FirstName_TB = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.OrderID = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.OrderDate_TB = New System.Windows.Forms.DateTimePicker()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.SearchOrdersButton = New System.Windows.Forms.Button()
        Me.DeleteOrderButton = New System.Windows.Forms.Button()
        CType(Me.OrdersDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Brand_TB
        '
        Me.Brand_TB.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.Brand_TB.Enabled = False
        Me.Brand_TB.Location = New System.Drawing.Point(170, 431)
        Me.Brand_TB.Name = "Brand_TB"
        Me.Brand_TB.Size = New System.Drawing.Size(100, 20)
        Me.Brand_TB.TabIndex = 77
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(465, 431)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(54, 13)
        Me.Label8.TabIndex = 76
        Me.Label8.Text = "Car Name"
        '
        'CarName_TB
        '
        Me.CarName_TB.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.CarName_TB.Enabled = False
        Me.CarName_TB.Location = New System.Drawing.Point(559, 431)
        Me.CarName_TB.Name = "CarName_TB"
        Me.CarName_TB.Size = New System.Drawing.Size(100, 20)
        Me.CarName_TB.TabIndex = 75
        '
        'Brand
        '
        Me.Brand.AutoSize = True
        Me.Brand.Location = New System.Drawing.Point(37, 438)
        Me.Brand.Name = "Brand"
        Me.Brand.Size = New System.Drawing.Size(35, 13)
        Me.Brand.TabIndex = 74
        Me.Brand.Text = "Brand"
        '
        'price_TB
        '
        Me.price_TB.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.price_TB.Enabled = False
        Me.price_TB.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.price_TB.HideSelection = False
        Me.price_TB.Location = New System.Drawing.Point(170, 374)
        Me.price_TB.Name = "price_TB"
        Me.price_TB.Size = New System.Drawing.Size(100, 20)
        Me.price_TB.TabIndex = 73
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(37, 377)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(31, 13)
        Me.Label9.TabIndex = 72
        Me.Label9.Text = "Price"
        '
        'RequiredDate_TB
        '
        Me.RequiredDate_TB.CustomFormat = "yyyy-MM-dd"
        Me.RequiredDate_TB.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.RequiredDate_TB.Location = New System.Drawing.Point(170, 273)
        Me.RequiredDate_TB.Name = "RequiredDate_TB"
        Me.RequiredDate_TB.Size = New System.Drawing.Size(200, 20)
        Me.RequiredDate_TB.TabIndex = 71
        '
        'ShippingDate_TB
        '
        Me.ShippingDate_TB.CustomFormat = "yyyy-MM-dd"
        Me.ShippingDate_TB.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.ShippingDate_TB.Location = New System.Drawing.Point(170, 315)
        Me.ShippingDate_TB.Name = "ShippingDate_TB"
        Me.ShippingDate_TB.Size = New System.Drawing.Size(200, 20)
        Me.ShippingDate_TB.TabIndex = 70
        '
        'OrdersDataGridView
        '
        Me.OrdersDataGridView.AllowUserToOrderColumns = True
        Me.OrdersDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.OrdersDataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.OrdersDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.OrdersDataGridView.Location = New System.Drawing.Point(93, 49)
        Me.OrdersDataGridView.Name = "OrdersDataGridView"
        Me.OrdersDataGridView.Size = New System.Drawing.Size(450, 150)
        Me.OrdersDataGridView.TabIndex = 68
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Location = New System.Drawing.Point(559, 533)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.Size = New System.Drawing.Size(75, 23)
        Me.Cancel_Button.TabIndex = 67
        Me.Cancel_Button.Text = "Cancel"
        Me.Cancel_Button.UseVisualStyleBackColor = True
        '
        'Label
        '
        Me.Label.AutoSize = True
        Me.Label.Location = New System.Drawing.Point(465, 328)
        Me.Label.Name = "Label"
        Me.Label.Size = New System.Drawing.Size(37, 13)
        Me.Label.TabIndex = 66
        Me.Label.Text = "Car ID"
        '
        'CarID_TB
        '
        Me.CarID_TB.BackColor = System.Drawing.SystemColors.ControlLight
        Me.CarID_TB.Enabled = False
        Me.CarID_TB.Location = New System.Drawing.Point(559, 321)
        Me.CarID_TB.Name = "CarID_TB"
        Me.CarID_TB.Size = New System.Drawing.Size(100, 20)
        Me.CarID_TB.TabIndex = 65
        '
        'Discount_TB
        '
        Me.Discount_TB.Location = New System.Drawing.Point(559, 381)
        Me.Discount_TB.Name = "Discount_TB"
        Me.Discount_TB.Size = New System.Drawing.Size(100, 20)
        Me.Discount_TB.TabIndex = 64
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(465, 381)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(49, 13)
        Me.Label14.TabIndex = 63
        Me.Label14.Text = "Discount"
        '
        'UpdateOdrerButton
        '
        Me.UpdateOdrerButton.Location = New System.Drawing.Point(40, 533)
        Me.UpdateOdrerButton.Name = "UpdateOdrerButton"
        Me.UpdateOdrerButton.Size = New System.Drawing.Size(116, 23)
        Me.UpdateOdrerButton.TabIndex = 62
        Me.UpdateOdrerButton.Text = "Update Order"
        Me.UpdateOdrerButton.UseVisualStyleBackColor = True
        '
        'OrderID_TB
        '
        Me.OrderID_TB.Location = New System.Drawing.Point(170, 14)
        Me.OrderID_TB.Name = "OrderID_TB"
        Me.OrderID_TB.Size = New System.Drawing.Size(100, 20)
        Me.OrderID_TB.TabIndex = 60
        '
        'CustomerID_TB
        '
        Me.CustomerID_TB.Location = New System.Drawing.Point(639, -54)
        Me.CustomerID_TB.Name = "CustomerID_TB"
        Me.CustomerID_TB.Size = New System.Drawing.Size(100, 20)
        Me.CustomerID_TB.TabIndex = 59
        '
        'LastName_TB
        '
        Me.LastName_TB.Location = New System.Drawing.Point(410, -54)
        Me.LastName_TB.Name = "LastName_TB"
        Me.LastName_TB.Size = New System.Drawing.Size(100, 20)
        Me.LastName_TB.TabIndex = 58
        '
        'FirstName_TB
        '
        Me.FirstName_TB.Location = New System.Drawing.Point(170, -54)
        Me.FirstName_TB.Name = "FirstName_TB"
        Me.FirstName_TB.Size = New System.Drawing.Size(100, 20)
        Me.FirstName_TB.TabIndex = 57
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(37, 321)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(74, 13)
        Me.Label7.TabIndex = 56
        Me.Label7.Text = "Shipping Date"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(37, 272)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(76, 13)
        Me.Label6.TabIndex = 55
        Me.Label6.Text = "Required Date"
        '
        'OrderID
        '
        Me.OrderID.AutoSize = True
        Me.OrderID.Location = New System.Drawing.Point(66, 17)
        Me.OrderID.Name = "OrderID"
        Me.OrderID.Size = New System.Drawing.Size(44, 13)
        Me.OrderID.TabIndex = 53
        Me.OrderID.Text = "OrderID"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(546, -51)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 13)
        Me.Label3.TabIndex = 52
        Me.Label3.Text = "Customer ID"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(299, -51)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(105, 13)
        Me.Label2.TabIndex = 51
        Me.Label2.Text = "Customer Last Name"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(60, -51)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(104, 13)
        Me.Label1.TabIndex = 50
        Me.Label1.Text = "Customer First Name"
        '
        'OrderDate_TB
        '
        Me.OrderDate_TB.CustomFormat = "yyyy-MM-dd"
        Me.OrderDate_TB.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.OrderDate_TB.Location = New System.Drawing.Point(559, 272)
        Me.OrderDate_TB.Name = "OrderDate_TB"
        Me.OrderDate_TB.Size = New System.Drawing.Size(200, 20)
        Me.OrderDate_TB.TabIndex = 69
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(465, 273)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(59, 13)
        Me.Label5.TabIndex = 54
        Me.Label5.Text = "Order Date"
        '
        'SearchOrdersButton
        '
        Me.SearchOrdersButton.Location = New System.Drawing.Point(333, 12)
        Me.SearchOrdersButton.Name = "SearchOrdersButton"
        Me.SearchOrdersButton.Size = New System.Drawing.Size(75, 23)
        Me.SearchOrdersButton.TabIndex = 78
        Me.SearchOrdersButton.Text = "Search Orders"
        Me.SearchOrdersButton.UseVisualStyleBackColor = True
        '
        'DeleteOrderButton
        '
        Me.DeleteOrderButton.Location = New System.Drawing.Point(313, 532)
        Me.DeleteOrderButton.Name = "DeleteOrderButton"
        Me.DeleteOrderButton.Size = New System.Drawing.Size(75, 23)
        Me.DeleteOrderButton.TabIndex = 79
        Me.DeleteOrderButton.Text = "Delete Order"
        Me.DeleteOrderButton.UseVisualStyleBackColor = True
        '
        'EditOrder
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(808, 628)
        Me.Controls.Add(Me.DeleteOrderButton)
        Me.Controls.Add(Me.SearchOrdersButton)
        Me.Controls.Add(Me.Brand_TB)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.CarName_TB)
        Me.Controls.Add(Me.Brand)
        Me.Controls.Add(Me.price_TB)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.RequiredDate_TB)
        Me.Controls.Add(Me.ShippingDate_TB)
        Me.Controls.Add(Me.OrderDate_TB)
        Me.Controls.Add(Me.OrdersDataGridView)
        Me.Controls.Add(Me.Cancel_Button)
        Me.Controls.Add(Me.Label)
        Me.Controls.Add(Me.CarID_TB)
        Me.Controls.Add(Me.Discount_TB)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.UpdateOdrerButton)
        Me.Controls.Add(Me.OrderID_TB)
        Me.Controls.Add(Me.CustomerID_TB)
        Me.Controls.Add(Me.LastName_TB)
        Me.Controls.Add(Me.FirstName_TB)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.OrderID)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "EditOrder"
        Me.Text = "Edit Order"
        CType(Me.OrdersDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Brand_TB As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents CarName_TB As TextBox
    Friend WithEvents Brand As Label
    Friend WithEvents price_TB As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents RequiredDate_TB As DateTimePicker
    Friend WithEvents ShippingDate_TB As DateTimePicker
    Friend WithEvents OrdersDataGridView As DataGridView
    Friend WithEvents Cancel_Button As Button
    Friend WithEvents Label As Label
    Friend WithEvents CarID_TB As TextBox
    Friend WithEvents Discount_TB As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents UpdateOdrerButton As Button
    Friend WithEvents OrderID_TB As TextBox
    Friend WithEvents CustomerID_TB As TextBox
    Friend WithEvents LastName_TB As TextBox
    Friend WithEvents FirstName_TB As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents OrderID As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents OrderDate_TB As DateTimePicker
    Friend WithEvents Label5 As Label
    Friend WithEvents SearchOrdersButton As Button
    Friend WithEvents DeleteOrderButton As Button
End Class
